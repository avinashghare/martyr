
  <div class="container">
      <div class="row">
         <div class="col-md-3"></div>
         
          <div class="col-md-6">
             <div class="head-reg text-center">
              <h2>No Data Found!!!</h2>
              </div>
          </div>
          <div class="col-md-3"></div>
      </div>
  </div>
  
    
    </div>
    