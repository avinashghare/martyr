

<?php echo $this->load->view('backend/'.$page); ?>

